$(document).ready(function() {
    var title = $("#mainTitle")
    title.animate({fontSize: '100px'}, "slow");
    title.animate({fontSize: '70px'}, "slow");
})